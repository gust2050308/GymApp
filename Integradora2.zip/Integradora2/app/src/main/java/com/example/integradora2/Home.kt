package com.example.integradora2

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.integradora2.databinding.ActivityHomeBinding
import org.json.JSONObject

class Home : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var queue: RequestQueue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializa Volley
        queue = Volley.newRequestQueue(this)

        // Configura el botón de Sign In
        binding.btnSignIn.setOnClickListener {
            // Obtén los datos del formulario (por ejemplo, nombre de usuario y contraseña)
            val username = binding.edtEmail.text.toString()
            val password = binding.edtPassword.text.toString()

            // Llama al método para enviar los datos a la API
            sendUserDataToApi(username, password)
        }
    }

    // Método para enviar los datos a la API
    private fun sendUserDataToApi(username: String, password: String) {
        val url = "http://192.168.63.19:3000/signin"  // URL de tu API

        // Crea el JSONObject con los datos del usuario
        val jsonObject = JSONObject()
        jsonObject.put("username", username)
        jsonObject.put("password", password)

        // Crea una solicitud POST con Volley usando JSONObject
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST,
            url,
            jsonObject,
            { response ->
                // Maneja la respuesta del servidor
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
            },
            { error ->
                // Maneja el error de la solicitud
                Toast.makeText(this, "Error al enviar los datos", Toast.LENGTH_SHORT).show()
            }
        )

        // Agrega la solicitud a la cola de Volley
        queue.add(jsonObjectRequest)
    }
}
