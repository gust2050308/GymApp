package com.example.integradora2

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.integradora2.databinding.ActivityRegistroBinding
import org.json.JSONObject

class Registro : AppCompatActivity() {
    private lateinit var binding: ActivityRegistroBinding
    private lateinit var queue: RequestQueue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializa la cola de solicitudes Volley
        queue = Volley.newRequestQueue(this)

        // Configura el botón de Registro
        binding.btnRegister.setOnClickListener {
            // Obtén los datos del formulario
            val nombre = binding.edtNombre.text.toString()
            val email = binding.edtEmail.text.toString()
            val telefono = binding.edtTelefono.text.toString()
            val fechaInicio = binding.edtInicioFecha.text.toString()
            val password = binding.edtPassword.text.toString()
            val confirmPassword = binding.edtConfirmPassword.text.toString()

            // Realiza las validaciones
            if (nombre.isEmpty() || email.isEmpty() || telefono.isEmpty() ||
                fechaInicio.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Llama al método para enviar los datos a la API
            sendUserDataToApi(nombre, email, telefono, fechaInicio, password)
        }
    }

    // Método para enviar los datos a la API
    private fun sendUserDataToApi(nombre: String, email: String, telefono: String, fechaInicio: String, password: String) {
        val url = "http://192.168.63.19:3000/registro"  // URL de tu API (reemplaza con la tuya)

        // Crea el JSONObject con los datos del usuario
        val jsonObject = JSONObject()
        jsonObject.put("nombre", nombre)
        jsonObject.put("email", email)
        jsonObject.put("telefono", telefono)
        jsonObject.put("fechaInicio", fechaInicio)
        jsonObject.put("password", password)

        // Crea una solicitud POST con Volley usando JSONObject
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST,
            url,
            jsonObject,
            { response ->
                // Maneja la respuesta del servidor
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
            },
            { error ->
                // Maneja el error de la solicitud
                Toast.makeText(this, "Error al enviar los datos", Toast.LENGTH_SHORT).show()
            }
        )

        // Agrega la solicitud a la cola de Volley
        queue.add(jsonObjectRequest)
    }
}
